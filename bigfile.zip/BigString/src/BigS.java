
/**Pendencias:
 *  -Leitura de Arquivo externo
 *  -Replace
 * 
 */


import java.util.HashMap;

public class BigS {
	
	public static void main (String[] args) {
		
		String []bigFile = {"AAAA|","CCC|","BBB|","123|","123|","CCC|"};
		HashMap<String, Integer> frasesRepetidas = new HashMap<String, Integer>();
		 int totalRepetidos=0;

		        for(int i=0 ;i<bigFile.length;i++)
		        {
		            int count=0;
		            for(int k=0;k<bigFile.length;k++)
		            {
		                if(bigFile[i]==bigFile[k])
		                {
		                    count++;
		                }
		            }

		            if(count>1)
		            {
		                if(!frasesRepetidas.containsKey(bigFile[i]))
		                {
		                    System.out.println(bigFile[i]+"Número de ocorrências: "+count);
		                    frasesRepetidas.put(bigFile[i], count);
		                    totalRepetidos+=count;
		                }
		            }
		        }
		        System.out.println("TOTAL DE FRASES REPETIDAS: "+totalRepetidos);

}}
