
/*  Usei um modelo coletado no stackOverFlow https://bit.ly/2tHjpLz
 *  
 *  Assim conclui que o propósito do Algoritmo é:
 *  Dado um Array A com N elementos e dado um número interiro (K),
 *  o resultado apresentado deverá ser a exibição na tela dos pares
 *  de números contido em A que somados resultam em K.
 *   
 *  Quanto o BIG-O, Segundo pesquisei pelo fato do algoritmo apresentado
 *  conter dois laços FOR não encadeados pode-se dizer que 0(n), baixa complexidade (Linear) 
 */



public class Kcomplementary {
	

	public static void main(String[] args) {

	    int A[]={1,2,3,4,5,6,7,15,18,32};
	    int K=33;
	    int arr1[]=new int[K];


	    for(int x=0;x<A.length;x++)
	    {
	        arr1[A[x]]++;
	    }

	    for(int y=0;y<A.length;y++)
	    {
	        if(arr1[K-A[y]]==1)
	        {
	            System.out.println(A[y]+","+(K-A[y]));
	        }
	    }

	}

}
