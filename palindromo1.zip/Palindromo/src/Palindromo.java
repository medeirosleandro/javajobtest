
/**

@author leandro
 *  
 */

import javax.swing.JOptionPane;

public class Palindromo {

	public static void main(String [] args) {

		String palavra;
		String palavraInvertida = "";

		palavra = JOptionPane.showInputDialog("Por favor insira a palavra: ");

		    // O FOR com base na Qtd de caracteres(posições) da palavra digitada

		for (int i = palavra.length() - 1; i >= 0; i--) {

			/*
			 * A String palavraInvertida irá receber o decremento da String palavra e o
			 * respectivo caracter na posição a cada laço
			 */

			palavraInvertida = palavraInvertida + palavra.charAt(i);
		}

		    /*
		     * Usando o método equalsIgnoreCase() comparo as Strings, anulando Case
		     * Sensitive e eliminando espaços com método trim().
		     */

		if (palavra.trim().equalsIgnoreCase(palavraInvertida.trim())) {

			JOptionPane.showMessageDialog(null,palavra +" é PALINDROMO!!!");

		} else {

			JOptionPane.showMessageDialog(null, palavra +" NÃO é PALINDROMO!!!");
		}
	}

}
